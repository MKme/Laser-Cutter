                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1287869
K3020 Laser Air Assist by kb0nly is licensed under the Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

On the newer K3020 clone of these 40w laser's the back wall is farther forward and the X-End bracket will hit it before the homing switch is reached, also at the head the cable chain will come into contact with the back wall as well so i had to push the cable chain farther forward and shortened and modified the X-End bracket as well as the carriage mounting bracket.  

The laser holder is made to fit a 12mmx30mm laser module, i used one with a cross pattern lense and after printing the laser holder it will be slightly undersized so i warmed up the part with a hot air gun and press fit the laser module into the holder.  Alternatively you could file it out for a snug fit and use a bit of glue, i used a dab of hot glue once the focus on the laser modules lens was adjusted to keep it from rotating and going out of focus.  I also modified the carriage mount for a single side mounted laser module, the original was setup to mount two laser modules for a cross dot setup but using the cross X-Lens version i didn't need that.

The Tab file is optional but if you want a Y-Axis cable chain then it gets glued to the side of the X-End mount, this was done in two parts just for easier printing and its plenty solid after being solvent welded to the other piece.  The other end of the Y-Axis cable chain is just attached to the bottom of the cabinet with some double sided adhesive mounting tape as it doesn't take much if any movement stress.  This gives a nice smooth running location for the air line and laser module power wiring.

I also modified the air tubing hole on the carriage mount to just pass the flexible silicone tubing i used for the air line, acts as a strain relief, and it loops down to the barbed fitting on the air assist nozzle. I used the air assist head from LightObject as its so cheap!!  Just take note that these machines have a 12mm diameter focal lens and the LightObject air assist head uses a 18mm, but there is a design on here for an adapter ring so i printed one of those and re-used my 12mm stock lens and it works great!